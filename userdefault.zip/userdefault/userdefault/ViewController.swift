//
//  ViewController.swift
//  userdefault
//
//  Created by MacStudent on 2017-10-18.
//  Copyright © 2017 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tfusername: UITextField!
     //var myUserDefault: UserDefaults!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet weak var tfpassword: UITextField!
    
    
    @IBOutlet weak var buttonlogin: UIButton!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func segue() {
        let storyBoard:UIStoryboard = UIStoryboard(name:"Main",bundle:nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "displayVC") as! displayVCViewController
        self.present(vc, animated: true, completion: nil)
        
    }
    @IBAction func buttonloginAction(_ sender: UIButton) {
        if tfusername.text == "abc" && tfpassword.text == "123"
        {
            let alert = UIAlertController(title: "alert", message: "welcome", preferredStyle: .alert)
            let alert1 = UIAlertAction(title: "ok", style: .default, handler: {action in self.segue()})
            alert.addAction(alert1)
            present(alert, animated:true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "alert", message: "password is wrong", preferredStyle: .alert)
            let alert1 = UIAlertAction(title: "ok", style: .destructive, handler: {action in self.segue()})
            alert.addAction(alert1)
            present(alert, animated:true, completion: nil)
            
        }
        
    }
    
    
}

